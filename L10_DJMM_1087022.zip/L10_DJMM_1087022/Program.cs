﻿using System;

class Program
{
    static void Main(string[] args)
    {
        TrianguloRectangulo triangulo = new TrianguloRectangulo();

        Console.Write("INGRESE EL CATETO A: ");
        triangulo.catetoA = double.Parse(Console.ReadLine());


        Console.Write("Ingrese El Angulo Opuesto a A: ");
        triangulo.anguloOpuestoA = double.Parse(Console.ReadLine());


        Console.WriteLine("CATETO B: " + triangulo.ObtenerCatetoB());
        Console.WriteLine("HIPOTENUSA: " + triangulo.ObtenerHipotenusa());
        Console.WriteLine("ANGULO OPUESTO a B: " + triangulo.ObtenerAnguloOpuestoB());
        Console.WriteLine("AREA DEL TRIANGULO: " + triangulo.ObtenerArea());
    }

}
