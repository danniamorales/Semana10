﻿using System;
namespace L10_DJMM_1087022
{
    internal class Circulo
    {
        public double radio;

        public double ObtenerPerimetro()
        {
            return 2 * Math.PI * radio;
        }

        public double ObtenerArea()
        {
            return Math.PI * radio * radio;
        }

        public double ObtenerVolumen()
        {
            return 4 * Math.PI * Math.Pow(radio, 3) / 3;
        }

        public void CalcularGeometria(ref double UnPerimetro, ref double UnArea, ref double UnVolumen)
        {
            UnPerimetro = ObtenerPerimetro();
            UnArea = ObtenerArea();
            UnVolumen = ObtenerVolumen();

        }
      
    }
}

